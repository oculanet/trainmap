import sqlite3
import os
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'dubai_metro_secret_key_2023'

# Configure database path
db_dir = os.path.expanduser('~/DubaiMetroDB')
os.makedirs(db_dir, exist_ok=True)
app.config['DATABASE'] = os.path.join(db_dir, 'metro.db')
print(f"Database will be created at: {app.config['DATABASE']}")

def get_db():
    """Get a database connection with proper error handling"""
    try:
        conn = sqlite3.connect(app.config['DATABASE'])
        conn.row_factory = sqlite3.Row
        return conn
    except sqlite3.Error as e:
        print(f"Database connection error: {e}")
        raise

def init_db():
    """Initialize the database with required tables and sample data"""
    conn = None
    try:
        conn = get_db()
        c = conn.cursor()

        # Drop tables if they exist (for development only)
        # c.execute("DROP TABLE IF EXISTS users")
        # c.execute("DROP TABLE IF EXISTS trains")
        # c.execute("DROP TABLE IF EXISTS depots")
        # c.execute("DROP TABLE IF EXISTS movements")

        # Create tables if they don't exist
        c.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                role TEXT NOT NULL
            )
        ''')

        c.execute('''
            CREATE TABLE IF NOT EXISTS trains (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                train_number TEXT UNIQUE NOT NULL,
                type TEXT NOT NULL,
                status TEXT NOT NULL,
                maintenance_type TEXT,
                location TEXT NOT NULL,
                last_movement TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        c.execute('''
            CREATE TABLE IF NOT EXISTS depots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                line TEXT NOT NULL,
                lmt_tracks INTEGER NOT NULL,
                hmt_tracks INTEGER NOT NULL,
                stabling_tracks INTEGER NOT NULL
            )
        ''')

        c.execute('''
            CREATE TABLE IF NOT EXISTS movements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                train_number TEXT NOT NULL,
                from_location TEXT NOT NULL,
                to_location TEXT NOT NULL,
                movement_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                operator TEXT NOT NULL,
                comments TEXT
            )
        ''')

        # Create default admin user if not exists
        try:
            hashed_pw = generate_password_hash('admin123')
            c.execute(
                "INSERT OR IGNORE INTO users (username, password, role) VALUES (?, ?, ?)",
                ('admin', hashed_pw, 'admin')
            )
            
            hashed_pw = generate_password_hash('operator123')
            c.execute(
                "INSERT OR IGNORE INTO users (username, password, role) VALUES (?, ?, ?)",
                ('operator', hashed_pw, 'operator')
            )
        except sqlite3.IntegrityError:
            pass

        # Insert depot data if not exists
        depots = [
            ('Jebel Ali Depot (JDP)', 'Red Line', 5, 2, 10),
            ('Rashidiya Depot (RDP)', 'Red Line', 6, 2, 10),
            ('Al Qusais Depot (QDP)', 'Green Line', 5, 2, 10)
        ]
        c.executemany(
            "INSERT OR IGNORE INTO depots (name, line, lmt_tracks, hmt_tracks, stabling_tracks) VALUES (?, ?, ?, ?, ?)",
            depots
        )

        # Insert sample train data if not exists
        trains = []
        for i in range(5001, 5080):
            trains.append((f"{i}", "KS", "Fit", None, "Mainline"))
        for i in range(5101, 5151):
            trains.append((f"{i}", "Alstom", "Fit", None, "Mainline"))
        
        # Modify some trains for testing
        trains[10] = ("5011", "KS", "Unfit", "28-Day PM", "JDP HMT-1")
        trains[25] = ("5026", "KS", "Unfit", "14-Day PM", "RDP LMT-4")
        trains[40] = ("5041", "KS", "Unfit", "CM", "QDP HMT-1")
        trains[60] = ("5061", "KS", "Fit", None, "JDP Stabling-3")
        trains[80] = ("5080", "KS", "Unfit", "19K PM", "QDP Wheel Lathe")
        trains[105] = ("5105", "Alstom", "Unfit", "CM", "RDP HMT-2")
        trains[120] = ("5120", "Alstom", "Unfit", "14-Day PM", "JDP LMT-2")

        c.executemany(
            "INSERT OR IGNORE INTO trains (train_number, type, status, maintenance_type, location) VALUES (?, ?, ?, ?, ?)",
            trains
        )

        # Insert sample movement logs
        movements = [
            ("5011", "Mainline", "JDP HMT-1", "admin", "Scheduled maintenance"),
            ("5026", "Mainline", "RDP LMT-4", "system", "Automatic movement"),
            ("5041", "Mainline", "QDP HMT-1", "system", "Automatic movement"),
            ("5061", "Mainline", "JDP Stabling-3", "operator", "End of service"),
            ("5080", "Mainline", "QDP Wheel Lathe", "admin", "Wheel maintenance"),
            ("5105", "Mainline", "RDP HMT-2", "system", "Automatic movement"),
            ("5120", "Mainline", "JDP LMT-2", "operator", "Scheduled inspection")
        ]
        c.executemany(
            "INSERT OR IGNORE INTO movements (train_number, from_location, to_location, operator, comments) VALUES (?, ?, ?, ?, ?)",
            movements
        )

        conn.commit()
        print("Database initialized successfully!")
    except Exception as e:
        print(f"Error initializing database: {str(e)}")
        raise
    finally:
        if conn:
            conn.close()

# Initialize database before first request
@app.before_request
def initialize_database():
    init_db()

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db()
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username = ?", (username,))
        user = c.fetchone()
        conn.close()
        
        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['role'] = user['role']
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials', 'error')
            return render_template('login.html', error='Invalid credentials')
    
    return render_template('login.html')

# Dashboard route

@app.route('/')
def dashboard():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    conn = get_db()
    c = conn.cursor()
    
    # Get summary stats
    stats = {
        'total_trains': c.execute("SELECT COUNT(*) FROM trains").fetchone()[0],
        'operational_trains': c.execute("SELECT COUNT(*) FROM trains WHERE status = 'Fit'").fetchone()[0],
        'maintenance_trains': c.execute("SELECT COUNT(*) FROM trains WHERE status = 'Unfit'").fetchone()[0],
        'mainline_trains': c.execute("SELECT COUNT(*) FROM trains WHERE location LIKE 'Mainline%'").fetchone()[0]
    }
    
    # Get organized depot data
    depots = []
    c.execute("SELECT * FROM depots ORDER BY name")
    for depot_row in c.fetchall():
        depot = {
            'id': depot_row['id'],
            'name': depot_row['name'],
            'line': depot_row['line'],
            'lmt_tracks': depot_row['lmt_tracks'],
            'hmt_tracks': depot_row['hmt_tracks'],
            'stabling_tracks': depot_row['stabling_tracks']
        }
        depot_code = depot['name'].split(' ')[0]  # JDP, RDP, QDP
        
        # Get all trains in this depot
        c.execute("""
            SELECT * FROM trains 
            WHERE location LIKE ? OR location LIKE ? OR location LIKE ? OR location LIKE ?
            ORDER BY location
        """, (
            f"{depot_code} LMT%",
            f"{depot_code} HMT%",
            f"{depot_code} Stabling%",
            f"{depot_code} %"  # For specialty tracks
        ))
        
        # Organize trains by track type
        tracks = {
            'lmt': [],
            'hmt': [],
            'specialty': [],
            'stabling': []
        }
        
        for train_row in c.fetchall():
            train = {
                'id': train_row['id'],
                'train_number': train_row['train_number'],
                'type': train_row['type'],
                'status': train_row['status'],
                'maintenance_type': train_row['maintenance_type'],
                'location': train_row['location'],
                'last_movement': train_row['last_movement']
            }
            location = train['location']
            
            if 'LMT' in location:
                tracks['lmt'].append(train)
            elif 'HMT' in location:
                tracks['hmt'].append(train)
            elif 'Stabling' in location:
                tracks['stabling'].append(train)
            else:
                # Specialty tracks (Wheel Lathe, CC Shoe Cleaning)
                tracks['specialty'].append(train)
        
        depots.append({
            'info': depot,
            'tracks': tracks
        })
    
    # Get recent movements
    movements = []
    for row in c.execute("SELECT * FROM movements ORDER BY movement_time DESC LIMIT 10").fetchall():
        movements.append(dict(row))
    
    conn.close()
    
    return render_template('dashboard.html', 
                         stats=stats,
                         depots=depots,
                         movements=movements,
                         username=session['username'],
                         role=session['role'],
                             datetime=datetime,  # <--
                         current_time=datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
# Train list route
@app.route('/trains')
def train_list():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    conn = get_db()
    c = conn.cursor()
    
    # Get filters from query parameters
    line_filter = request.args.get('line', 'all')
    type_filter = request.args.get('type', 'all')
    status_filter = request.args.get('status', 'all')
    maintenance_filter = request.args.get('maintenance', 'all')
    
    # Build query
    query = "SELECT * FROM trains"
    conditions = []
    params = []
    
    if line_filter != 'all':
        conditions.append("(location LIKE ? OR location LIKE ?)")
        if line_filter == 'Red':
            params.extend(['JDP%', 'RDP%'])
        else:  # Green Line
            params.extend(['QDP%'])
    
    if type_filter != 'all':
        conditions.append("type = ?")
        params.append(type_filter)
    
    if status_filter != 'all':
        conditions.append("status = ?")
        params.append(status_filter)
    
    if maintenance_filter != 'all':
        conditions.append("maintenance_type = ?")
        params.append(maintenance_filter)
    
    if conditions:
        query += " WHERE " + " AND ".join(conditions)
    
    query += " ORDER BY train_number"
    c.execute(query, tuple(params))
    trains = c.fetchall()
    
    conn.close()
    
    return render_template('train_list.html', 
                          trains=trains,
                          filters={
                              'line': line_filter,
                              'type': type_filter,
                              'status': status_filter,
                              'maintenance': maintenance_filter
                          },
                          username=session['username'],
                          role=session['role'],
                          datetime=datetime)

# Update train status route
@app.route('/update_train/<train_number>', methods=['GET', 'POST'])
def update_train(train_number):
    if 'username' not in session:
        return redirect(url_for('login'))
    
    if session['role'] != 'admin':
        flash('Admin access required', 'error')
        return redirect(url_for('train_list'))
    
    conn = get_db()
    c = conn.cursor()
    
    if request.method == 'POST':
        new_status = request.form['status']
        maintenance_type = request.form.get('maintenance_type') if new_status == 'Unfit' else None
        new_location = request.form['location']
        comments = request.form.get('comments', '')
        
        # Get current location
        c.execute("SELECT location FROM trains WHERE train_number = ?", (train_number,))
        current_location = c.fetchone()['location']
        
        try:
            # Update train status
            c.execute("""
                UPDATE trains 
                SET status = ?, maintenance_type = ?, location = ?, last_movement = datetime('now') 
                WHERE train_number = ?
            """, (new_status, maintenance_type, new_location, train_number))
            
            # Add to movement log
            c.execute("""
                INSERT INTO movements 
                (train_number, from_location, to_location, operator, comments) 
                VALUES (?, ?, ?, ?, ?)
            """, (train_number, current_location, new_location, session['username'], comments))
            
            conn.commit()
            flash(f"Train {train_number} status updated successfully", 'success')
        except sqlite3.Error as e:
            conn.rollback()
            flash(f"Error updating train status: {str(e)}", 'error')
        finally:
            conn.close()
            return redirect(url_for('train_list'))
    
    # GET request - show update form
    c.execute("SELECT * FROM trains WHERE train_number = ?", (train_number,))
    train = c.fetchone()
    
    c.execute("SELECT * FROM depots")
    depots = c.fetchall()
    
    conn.close()
    
    return render_template('update_train.html', 
                          train=dict(train),
                          depots=depots,
                          username=session['username'],
                          role=session['role'],
                          datetime=datetime)

# Depot view route
@app.route('/depot_view/<depot_name>')
def depot_view(depot_name):
    if 'username' not in session:
        return redirect(url_for('login'))
    
    return render_template('depot_view.html', 
                          depot_name=depot_name,
                          username=session['username'],
                          role=session['role'],
                          datetime=datetime)

# Train history route
@app.route('/train_history/<train_number>')
def train_history(train_number):
    if 'username' not in session:
        return redirect(url_for('login'))
    
    conn = get_db()
    c = conn.cursor()
    
    # Get train info
    c.execute("SELECT * FROM trains WHERE train_number = ?", (train_number,))
    train = c.fetchone()
    
    if not train:
        conn.close()
        flash('Train not found', 'error')
        return redirect(url_for('train_list'))
    
    # Get movement history
    c.execute("""
        SELECT * FROM movements 
        WHERE train_number = ? 
        ORDER BY movement_time DESC
    """, (train_number,))
    history = c.fetchall()
    
    conn.close()
    
    return render_template('train_history.html', 
                          train=dict(train),
                          history=history,
                          username=session['username'],
                          role=session['role'],
                          datetime=datetime)

# API to get depot layout
@app.route('/api/depot_layout/<depot_name>')
def depot_layout(depot_name):
    conn = get_db()
    c = conn.cursor()
    
    # Get depot info
    c.execute("SELECT * FROM depots WHERE name = ?", (depot_name,))
    depot = c.fetchone()
    
    if not depot:
        conn.close()
        return jsonify({"error": "Depot not found"}), 404
    
    # Get all tracks
    tracks = []
    
    # LMT Tracks
    for i in range(1, depot['lmt_tracks'] + 1):
        track_name = f"{depot_name.split(' ')[0]} LMT-{i}"
        c.execute("SELECT * FROM trains WHERE location = ?", (track_name,))
        trains = [dict(row) for row in c.fetchall()]
        tracks.append({
            "name": track_name,
            "type": "LMT",
            "trains": trains
        })
    
    # HMT Tracks
    for i in range(1, depot['hmt_tracks'] + 1):
        track_name = f"{depot_name.split(' ')[0]} HMT-{i}"
        c.execute("SELECT * FROM trains WHERE location = ?", (track_name,))
        trains = [dict(row) for row in c.fetchall()]
        tracks.append({
            "name": track_name,
            "type": "HMT",
            "trains": trains
        })
    
    # Specialty Tracks (only for QDP)
    if depot_name == 'Al Qusais Depot (QDP)':
        specialty_tracks = [
            {"name": "QDP Wheel Lathe", "type": "Wheel Lathe"},
            {"name": "QDP CC Shoe Cleaning", "type": "CC Shoe Cleaning"}
        ]
        
        for track in specialty_tracks:
            c.execute("SELECT * FROM trains WHERE location = ?", (track['name'],))
            track['trains'] = [dict(row) for row in c.fetchall()]
            tracks.append(track)
    
    # Stabling Tracks
    for i in range(1, depot['stabling_tracks'] + 1):
        track_name = f"{depot_name.split(' ')[0]} Stabling-{i}"
        c.execute("SELECT * FROM trains WHERE location = ?", (track_name,))
        trains = [dict(row) for row in c.fetchall()]
        tracks.append({
            "name": track_name,
            "type": "Stabling",
            "trains": trains
        })
    
    conn.close()
    return jsonify({
        "depot": dict(depot),
        "tracks": tracks
    })

# Logout route
@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out', 'info')
    return redirect(url_for('login'))

if __name__ == '__main__':
    # Create database directory if it doesn't exist
    os.makedirs(os.path.dirname(app.config['DATABASE']), exist_ok=True)
    app.run(debug=True, port=5000)