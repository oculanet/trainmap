import sqlite3

DB_PATH = 'metro.db'  # Change this if your DB is in a different location

def add_comments_column():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    try:
        c.execute("ALTER TABLE movements ADD COLUMN comments TEXT;")
        print("Successfully added 'comments' column to movements table.")
    except sqlite3.OperationalError as e:
        if 'duplicate column name' in str(e).lower():
            print("'comments' column already exists. No changes made.")
        else:
            print("Error occurred:", e)
    finally:
        conn.commit()
        conn.close()

if __name__ == "__main__":
    add_comments_column()
